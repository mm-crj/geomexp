from setuptools import setup, find_packages
from codecs import open
from os import path

here = path.abspath(path.dirname(__file__))

with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(name='geomexp',
      version='0.2.2',
      description='2-d gemometric illusion experiments',
      url='https://github.com/mm-crj/geomexp',
      author='Mainak Mandal',
      author_email='mm.crjx@gmail.com',
      license='GNU LGPLv3',
      long_description=long_description,
#      long_description=open('README.md').read(),
      long_description_content_type='text/markdown',
      packages=find_packages(exclude=['build', 'docs', 'templates']),
      package_data={
        'data':
             [],
        'images/baldwin':
            ['images/baldwin/bw_exp_s1.5-1.png',
             'images/baldwin/bw_exp_s1.5.png',
             'images/baldwin/bw_exp_s2-1.png',
             'images/baldwin/bw_exp_s2.5.png',
             'images/baldwin/bw_exp_s2.5-1.png',
             'images/baldwin/bw_exp_s2.png',
             'images/baldwin/bw_exp_s3-1.png',
             'images/baldwin/bw_exp_s3.4.png',
             'images/baldwin/bw_exp_s3.5-1.png',
             'images/baldwin/bw_exp_s3.png',
             'images/baldwin/bw_exp_s4-1.png',
             'images/baldwin/bw_exp_s.png',
             'images/baldwin/bw_sim_s1.0.png',
             'images/baldwin/bw_sim_s1-1.5.png',
             'images/baldwin/bw_sim_s1-2.0.png',
             'images/baldwin/bw_sim_s1-2.5.png',
             'images/baldwin/bw_sim_s1-3.0.png',
             'images/baldwin/bw_sim_s1-3.5.png',
             'images/baldwin/bw_sim_s2.0.png',
             'images/baldwin/bw_sim_s1.5.png',
             'images/baldwin/bw_sim_s2.5.png',
             'images/baldwin/bw_sim_s3.4.png',
             'images/baldwin/bw_sim_s3.png'],
        'images/ml':
            ['images/ml/ml_exp_10.png',
             'images/ml/ml_exp_100.png',
             'images/ml/ml_exp_10.png',
             'images/ml/ml_exp_110.png',
             'images/ml/ml_exp_120.png',
             'images/ml/ml_exp_130.png',
             'images/ml/ml_exp_140.png',
             'images/ml/ml_exp_150.png',
             'images/ml/ml_exp_160.png',
             'images/ml/ml_exp_170.png',
             'images/ml/ml_exp_20.png',
             'images/ml/ml_exp_30.png',
             'images/ml/ml_exp_40.png',
             'images/ml/ml_exp_50.png',
             'images/ml/ml_exp_60.png',
             'images/ml/ml_exp_70.png',
             'images/ml/ml_exp_80.png',
             'images/ml/ml_exp_90.png'],
    },
      python_requires='<= 2.8',
      classifiers=[
      'Development Status :: 2 - Pre-Alpha',
      'Intended Audience :: Education',
      'License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)',
      'Programming Language :: Python',
      'Programming Language :: Python :: 2.7',
      'Operating System :: POSIX :: Linux',
      'Operating System :: Microsoft :: Windows',
      'Operating System :: MacOS :: MacOS X',
      ],
       install_requires=['numpy>=1.16.6',
                         'psychopy>=1.85.2',
                         'pandas>=0.24.2',
                         'pygments>=2.4.2'
                         'wxPython>=4.0.4',
                         'pyyaml>=5.1.2',
                         'psutil>=5.6.3',
                         'msgpack>=1.0.0',
                         'gevent>=1.3.0',
                         'python-xlib>=0.26']
)
